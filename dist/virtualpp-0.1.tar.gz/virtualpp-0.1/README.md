# SINGLE PINGPONG-hand (Check out final.py)
Playing a pingpong game with just color detection (here orange) using opencv and python scripts
<p align="center">
  <img src="https://i.chzbgr.com/full/6686158592/h4715F533/"
       height="500" width="500"alt="PONG"/>
</p>
**********

**opencv is a computer vision library**


Here we used opencv to detect a specific colour(of the glove),and draw a contour over it and use the glove movements to move the centroid obtained from the operations.This will in turn move the paddle for the game.

The Game is written such a way that there is only a single player and you gotta survive for as much time as possible.
Before installaton , you need the following.

1)python 3

2)pygame

3)opencv 3.4or higher

(optional)You can integrate this into a projector inside a dark room and it will give good results.

Contributors:

1)Augustin Jose
https://github.com/AugustinJose1221

2)Abhijith Neil Abraham



Check out the file "final.py"
and you will see comments well documented to understand the code.
P.S. please remember to show an orange object in front of the camera before launching the code.Else,you will see an error. 
